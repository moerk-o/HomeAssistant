"""Image platform for WhenHub integration."""
from __future__ import annotations
from typing import Any


import logging
import os
import base64

from homeassistant.components.image import ImageEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import (
    DOMAIN,
    EVENT_TYPES,
    EVENT_TYPE_TRIP,
    CONF_EVENT_TYPE,
    CONF_EVENT_NAME,
    CONF_IMAGE_PATH,
)

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up WhenHub image based on a config entry."""
    event_data = hass.data[DOMAIN][config_entry.entry_id]
    
    # Immer eine Bild-Entity erstellen
    image_entity = WhenHubImage(hass, config_entry, event_data)
    async_add_entities([image_entity])


class WhenHubImage(ImageEntity):
    """Representation of a WhenHub Image."""

    def __init__(self, hass: HomeAssistant, config_entry: ConfigEntry, event_data: dict) -> None:
        """Initialize the image entity."""
        super().__init__(hass)
        
        self._config_entry = config_entry
        self._event_data = event_data
        self._attr_name = f"{event_data[CONF_EVENT_NAME]} Image"
        self._attr_unique_id = f"{config_entry.entry_id}_image"
        
        # Set image path if provided
        self._image_path = event_data.get(CONF_IMAGE_PATH)
        self._image_data = event_data.get("image_data")
        
        _LOGGER.debug("Initializing image entity - path: %s, has_data: %s", 
                     self._image_path, bool(self._image_data))

    @property
    def device_info(self) -> DeviceInfo:
        """Return device information about this entity."""
        # Get event type for proper model name
        event_type = self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_TRIP)
        event_info = EVENT_TYPES.get(event_type, EVENT_TYPES[EVENT_TYPE_TRIP])
        
        return DeviceInfo(
            identifiers={(DOMAIN, self._config_entry.entry_id)},
            name=self._event_data[CONF_EVENT_NAME],
            manufacturer="WhenHub",
            model=event_info["model"],
            sw_version="1.0.0",
        )

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return the state attributes."""
        attributes = {}
        
        # Determine image type and path
        if self._image_data:
            # Base64 uploaded image
            attributes["image_type"] = "user_defined"
            attributes["image_path"] = "base64_data"
        elif self._image_path:
            # User provided file path
            attributes["image_type"] = "user_defined"
            attributes["image_path"] = self._image_path
        else:
            # Default system-generated SVG
            attributes["image_type"] = "system_defined"
            attributes["image_path"] = "default_svg"
        
        return attributes

    async def async_image(self) -> bytes | None:
        """Return bytes of image."""
        try:
            # First try uploaded image data (Base64)
            if self._image_data:
                _LOGGER.debug("Loading image from Base64 data")
                try:
                    return base64.b64decode(self._image_data)
                except Exception as err:
                    _LOGGER.error("Error decoding Base64 image: %s", err)
            
            # Then try image path
            if self._image_path:
                _LOGGER.debug("Loading image from path: %s", self._image_path)
                
                # Handle /local/ paths
                if self._image_path.startswith("/local/"):
                    local_path = self._image_path.replace("/local/", "")
                    file_path = os.path.join(self.hass.config.config_dir, "www", local_path)
                    
                    if os.path.exists(file_path):
                        _LOGGER.debug("Found image file at: %s", file_path)
                        with open(file_path, "rb") as f:
                            return f.read()
                    else:
                        _LOGGER.warning("Image file not found: %s", file_path)
                
                # Handle absolute paths
                elif os.path.exists(self._image_path):
                    _LOGGER.debug("Found image file at absolute path: %s", self._image_path)
                    with open(self._image_path, "rb") as f:
                        return f.read()
                else:
                    _LOGGER.warning("Image file not found at path: %s", self._image_path)
            
            # Return default colored background if nothing else works
            _LOGGER.debug("Using default colored background")
            return self._get_default_image()
                
        except Exception as err:
            _LOGGER.error("Error loading image: %s", err)
            return self._get_default_image()

    def _get_default_image(self) -> bytes:
        """Return a default image based on event type."""
        # Get event type and corresponding color/icon
        event_type = self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_TRIP)
        
        # Define colors and icons for each event type
        if event_type == EVENT_TYPE_TRIP:
            color = "#4a90e2"  # Blue
            icon_path = "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"  # Airplane-like
        elif event_type == "milestone":
            color = "#e74c3c"  # Red
            icon_path = "M14.4 6L14 4H5v17h2v-7h5.6l.4 2h7V6z"  # Flag
        elif event_type == "anniversary":
            color = "#e91e63"  # Pink
            icon_path = "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"  # Heart
        else:
            color = "#4a90e2"  # Default blue
            icon_path = "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
        
        svg_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<svg width="400" height="300" xmlns="http://www.w3.org/2000/svg">
  <rect width="100%" height="100%" fill="{color}"/>
  <g transform="translate(200,150) scale(8,8) translate(-12,-12)">
    <path d="{icon_path}" fill="white" fill-opacity="0.8"/>
  </g>
</svg>'''
        return svg_content.encode('utf-8')

    @property
    def state(self) -> str:
        """Return the state of the image entity."""
        return "idle"

    @property  
    def content_type(self) -> str:
        """Return the content type of the image."""
        # Check if we're returning the default SVG
        if not self._image_path and not self._image_data:
            return "image/svg+xml"
        
        # For user images, detect from path or assume JPEG
        if self._image_path:
            if self._image_path.lower().endswith('.png'):
                return "image/png"
            elif self._image_path.lower().endswith(('.webp', '.gif')):
                return f"image/{self._image_path.split('.')[-1].lower()}"
            elif self._image_path.lower().endswith('.svg'):
                return "image/svg+xml"
        
        return "image/jpeg"