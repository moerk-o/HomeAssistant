"""WhenHub Integration for Home Assistant."""
from __future__ import annotations

import logging

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers import entity_registry as er

from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

PLATFORMS: list[Platform] = [Platform.SENSOR, Platform.IMAGE, Platform.BINARY_SENSOR]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up WhenHub from a config entry."""
    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = entry.data

    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    
    # RICHTIGE Syntax für Update Listener
    entry.async_on_unload(entry.add_update_listener(async_update_listener))
    
    _LOGGER.debug("Successfully set up WhenHub entry: %s", entry.title)
    
    return True


async def async_update_listener(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Handle options update."""
    _LOGGER.debug("Updating WhenHub entry: %s", entry.title)
    
    # Daten in hass.data aktualisieren
    hass.data[DOMAIN][entry.entry_id] = entry.data
    
    # Sanfter Reload: Nur die Platforms neu laden, nicht die ganze Integration
    await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    
    _LOGGER.debug("Successfully updated WhenHub entry: %s", entry.title)


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    _LOGGER.debug("Unloading WhenHub entry: %s", entry.title)
    
    if unload_ok := await hass.config_entries.async_unload_platforms(entry, PLATFORMS):
        # Daten aus hass.data entfernen
        hass.data[DOMAIN].pop(entry.entry_id)
        
        # Entities aus der Entity Registry entfernen
        entity_registry = er.async_get(hass)
        entities = er.async_entries_for_config_entry(entity_registry, entry.entry_id)
        
        # GEÄNDERT: Entferne das manuelle Event-Feuern - das macht HA automatisch
        for entity in entities:
            _LOGGER.debug("Removing entity: %s", entity.entity_id)
            entity_registry.async_remove(entity.entity_id)
        
        # ENTFERNT: Das manuelle Event-Feuern verursacht die KeyError
        # Home Assistant feuert automatisch korrekte Events wenn Entities entfernt werden
        
        _LOGGER.info("Successfully unloaded WhenHub entry '%s' and removed %d entities", 
                    entry.title, len(entities))
    else:
        _LOGGER.error("Failed to unload WhenHub entry: %s", entry.title)

    return unload_ok