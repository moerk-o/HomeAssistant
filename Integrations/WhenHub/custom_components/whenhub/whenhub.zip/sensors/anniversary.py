"""Anniversary sensor for WhenHub integration."""
from __future__ import annotations

import logging
from datetime import date
from typing import Any

from homeassistant.config_entries import ConfigEntry

from ..const import (
    CONF_TARGET_DATE,
    CONF_EVENT_TYPE,
    CONF_EVENT_NAME,
    EVENT_TYPE_ANNIVERSARY,
    ANNIVERSARY_SENSOR_TYPES,
)
from .base import BaseCountdownSensor

_LOGGER = logging.getLogger(__name__)


class AnniversarySensor(BaseCountdownSensor):
    """Representation of an Anniversary Sensor."""

    def __init__(self, config_entry: ConfigEntry, event_data: dict, sensor_type: str) -> None:
        """Initialize the anniversary sensor."""
        super().__init__(config_entry, event_data, sensor_type, ANNIVERSARY_SENSOR_TYPES)
        
        # Parse original date
        target_date = event_data.get(CONF_TARGET_DATE)
        if not target_date:
            _LOGGER.error("No target_date found for anniversary sensor, event_data: %s", event_data)
            target_date = date.today().isoformat()
        
        self._original_date = self._parse_date(target_date)

    def _get_next_anniversary(self) -> date:
        """Calculate next anniversary date."""
        try:
            today = date.today()
            current_year = today.year
            
            # Try this year's anniversary
            try:
                this_year_anniversary = self._original_date.replace(year=current_year)
                if this_year_anniversary >= today:
                    return this_year_anniversary
            except ValueError:
                # Handle leap year edge case (Feb 29 -> Feb 28 in non-leap years)
                this_year_anniversary = date(current_year, 2, 28)
                if this_year_anniversary >= today:
                    return this_year_anniversary
            
            # If this year's anniversary has already passed, get next year's
            try:
                next_year_anniversary = self._original_date.replace(year=current_year + 1)
                return next_year_anniversary
            except ValueError:
                # Handle leap year edge case (Feb 29 -> Feb 28 in non-leap years)
                return date(current_year + 1, 2, 28)
                
        except Exception as err:
            _LOGGER.error("Error calculating next anniversary: %s", err)
            return self._original_date

    def _get_last_anniversary(self) -> date:
        """Calculate last anniversary date."""
        try:
            today = date.today()
            current_year = today.year
            
            # If original date is in the future, there's no "last" anniversary yet
            if self._original_date > today:
                return self._original_date  # Return the original date itself
            
            # Try this year's anniversary
            try:
                this_year_anniversary = self._original_date.replace(year=current_year)
                if this_year_anniversary <= today:
                    return this_year_anniversary
            except ValueError:
                # Handle leap year edge case (Feb 29 -> Feb 28 in non-leap years)
                this_year_anniversary = date(current_year, 2, 28)
                if this_year_anniversary <= today:
                    return this_year_anniversary
            
            # If this year's anniversary hasn't happened yet, get last year's
            try:
                last_year_anniversary = self._original_date.replace(year=current_year - 1)
                return last_year_anniversary
            except ValueError:
                # Handle leap year edge case (Feb 29 -> Feb 28 in non-leap years)
                return date(current_year - 1, 2, 28)
                
        except Exception as err:
            _LOGGER.error("Error calculating last anniversary: %s", err)
            return self._original_date

    def _count_occurrences(self) -> int:
        """Count how many times this anniversary has occurred (including today if it's the anniversary)."""
        today = date.today()
        
        # If original date is in the future, no occurrences yet
        if self._original_date > today:
            return 0
        
        # Calculate base occurrences (full years that have passed)
        years_passed = today.year - self._original_date.year
        
        # Check if this year's anniversary has already happened
        try:
            this_year_anniversary = self._original_date.replace(year=today.year)
            if this_year_anniversary > today:
                # This year's anniversary hasn't happened yet
                years_passed -= 1
        except ValueError:
            # Handle leap year edge case (Feb 29)
            this_year_anniversary = date(today.year, 2, 28)
            if this_year_anniversary > today:
                years_passed -= 1
        
        # Add 1 because we count the original occurrence
        return max(1, years_passed + 1)  # Minimum 1 (the original occurrence)

    def _get_fallback_value(self) -> str | int | None:
        """Get a safe fallback value based on sensor type."""
        if self._sensor_type in ["days_until_next", "days_since_last", "occurrences_count"]:
            return 0
        elif self._sensor_type == "countdown_text":
            return "Berechnung läuft..."
        elif self._sensor_type in ["next_date", "last_date"]:
            return date.today().isoformat()
        return None

    @property
    def available(self) -> bool:
        """Return if entity is available."""
        return self._original_date is not None

    @property
    def native_value(self) -> str | int | float | None:
        """Return the native value of the sensor."""
        try:
            return self._calculate_value()
        except Exception as err:
            _LOGGER.error("Error in native_value for sensor %s: %s", self._sensor_type, err)
            return self._get_fallback_value()

    def _calculate_value(self) -> str | int | float | None:
        """Calculate the current value."""
        today = date.today()
        
        if self._sensor_type == "days_until_next":
            next_anniversary = self._get_next_anniversary()
            return (next_anniversary - today).days
        
        elif self._sensor_type == "days_since_last":
            last_anniversary = self._get_last_anniversary()
            return (today - last_anniversary).days
            
        elif self._sensor_type == "countdown_text":
            next_anniversary = self._get_next_anniversary()
            days_until = (next_anniversary - today).days
            if days_until == 0:
                return "0 Tage"
            else:
                return self._format_countdown_with_attributes(next_anniversary)
                
        elif self._sensor_type == "occurrences_count":
            return self._count_occurrences()
                
        elif self._sensor_type == "next_date":
            next_anniversary = self._get_next_anniversary()
            return next_anniversary.isoformat()
            
        elif self._sensor_type == "last_date":
            last_anniversary = self._get_last_anniversary()
            return last_anniversary.isoformat()
        
        return None

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return the state attributes."""
        # Nur der Countdown Text Sensor bekommt Attribute (wie Trip/Milestone)
        if self._sensor_type == "countdown_text":
            attributes = {
                "event_name": self._event_data[CONF_EVENT_NAME],
                "event_type": self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_ANNIVERSARY),
                "initial_date": self._original_date.isoformat(),
            }
            
            # Add countdown breakdown attributes
            attributes.update(self._get_countdown_attributes())
            
            return attributes
        
        # Alle anderen Anniversary-Sensoren haben keine Attribute
        return {}