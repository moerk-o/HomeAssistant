"""Trip sensor for WhenHub integration."""
from __future__ import annotations

import logging
from datetime import date
from typing import Any

from homeassistant.config_entries import ConfigEntry

from ..const import (
    CONF_START_DATE,
    CONF_END_DATE,
    CONF_EVENT_TYPE,
    CONF_EVENT_NAME,
    EVENT_TYPE_TRIP,
    TRIP_SENSOR_TYPES,
)
from .base import BaseCountdownSensor

_LOGGER = logging.getLogger(__name__)


class TripSensor(BaseCountdownSensor):
    """Representation of a Trip Sensor."""

    def __init__(self, config_entry: ConfigEntry, event_data: dict, sensor_type: str) -> None:
        """Initialize the trip sensor."""
        super().__init__(config_entry, event_data, sensor_type, TRIP_SENSOR_TYPES)
        
        # Parse dates
        self._start_date = self._parse_date(event_data[CONF_START_DATE])
        self._end_date = self._parse_date(event_data[CONF_END_DATE])

    @property
    def native_value(self) -> str | int | float | None:
        """Return the native value of the sensor."""
        try:
            today = date.today()
            
            if self._sensor_type == "days_until":
                return (self._start_date - today).days
                
            elif self._sensor_type == "days_until_end":
                return (self._end_date - today).days
                
            elif self._sensor_type == "countdown_text":
                if today <= self._start_date:
                    return self._format_countdown_with_attributes(self._start_date)
                else:
                    return "0 Tage"
                    
            elif self._sensor_type == "trip_left_days":
                if today <= self._end_date and today >= self._start_date:
                    return (self._end_date - today).days + 1
                return 0
                
            elif self._sensor_type == "trip_left_percent":
                total_days = (self._end_date - self._start_date).days
                if today < self._start_date:
                    return 100.0  # 100% noch übrig
                elif today > self._end_date:
                    return 0.0    # 0% übrig
                else:
                    passed_days = (today - self._start_date).days
                    remaining_percent = 100.0 - ((passed_days / total_days) * 100.0)
                    return round(remaining_percent, 1)
                    
            return None
        except Exception as err:
            _LOGGER.error("Error calculating native_value for TripSensor %s: %s", self._sensor_type, err)
            return None

    def _format_countdown(self, delta) -> str:
        """Format timedelta into precise years, months, weeks, days format."""
        total_days = delta.days
        
        if total_days == 0:
            return "0 Tage"
        
        # Simple approximation approach for reliability
        years = total_days // 365
        remaining_days = total_days - (years * 365)
        
        months = remaining_days // 30
        remaining_days = remaining_days - (months * 30)
        
        weeks = remaining_days // 7
        days = remaining_days % 7
        
        # Store values for attributes
        self._countdown_breakdown = {
            "years": years,
            "months": months,
            "weeks": weeks,
            "days": days
        }
        
        # Build result string, omitting zero values
        parts = []
        if years > 0:
            parts.append(f"{years} Jahr{'e' if years > 1 else ''}")
        if months > 0:
            parts.append(f"{months} Monat{'e' if months > 1 else ''}")
        if weeks > 0:
            parts.append(f"{weeks} Woche{'n' if weeks > 1 else ''}")
        if days > 0:
            parts.append(f"{days} Tag{'e' if days > 1 else ''}")
        
        # Join with commas only (no 'und')
        if len(parts) == 0:
            return "0 Tage"
        else:
            return ", ".join(parts)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return the state attributes."""
        # Nur der Countdown Text Sensor bekommt Attribute
        if self._sensor_type == "countdown_text":
            attributes = {
                "event_name": self._event_data[CONF_EVENT_NAME],
                "event_type": self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_TRIP),
                "start_date": self._start_date.isoformat(),
                "end_date": self._end_date.isoformat(),
                "total_days": (self._end_date - self._start_date).days + 1,
            }
            
            # Add countdown breakdown attributes
            attributes.update(self._get_countdown_attributes())
            
            return attributes
        
        # Alle anderen Trip-Sensoren haben keine Attribute
        return {}