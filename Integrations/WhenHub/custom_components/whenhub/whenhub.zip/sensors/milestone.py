"""Milestone sensor for WhenHub integration."""
from __future__ import annotations

import logging
from datetime import date
from typing import Any

from homeassistant.config_entries import ConfigEntry

from ..const import (
    CONF_TARGET_DATE,
    CONF_EVENT_TYPE,
    CONF_EVENT_NAME,
    EVENT_TYPE_MILESTONE,
    MILESTONE_SENSOR_TYPES,
)
from .base import BaseCountdownSensor

_LOGGER = logging.getLogger(__name__)


class MilestoneSensor(BaseCountdownSensor):
    """Representation of a Milestone Sensor."""

    def __init__(self, config_entry: ConfigEntry, event_data: dict, sensor_type: str) -> None:
        """Initialize the milestone sensor."""
        super().__init__(config_entry, event_data, sensor_type, MILESTONE_SENSOR_TYPES)
        
        # Parse target date
        self._target_date = self._parse_date(event_data[CONF_TARGET_DATE])

    @property
    def native_value(self) -> str | int | float | None:
        """Return the native value of the sensor."""
        try:
            today = date.today()
            
            if self._sensor_type == "days_until":
                return (self._target_date - today).days
                
            elif self._sensor_type == "countdown_text":
                if today < self._target_date:
                    return self._format_countdown_with_attributes(self._target_date)
                else:
                    return "0 Tage"
                    
            return None
        except Exception as err:
            _LOGGER.error("Error calculating native_value for MilestoneSensor %s: %s", self._sensor_type, err)
            return None

    def _format_countdown_milestone(self, delta) -> str:
        """Format timedelta into precise years, months, weeks, days format."""
        total_days = delta.days
        
        if total_days == 0:
            return "0 Tage"
        
        # Simple approximation approach for reliability
        years = total_days // 365
        remaining_days = total_days - (years * 365)
        
        months = remaining_days // 30
        remaining_days = remaining_days - (months * 30)
        
        weeks = remaining_days // 7
        days = remaining_days % 7
        
        # Store values for attributes
        self._countdown_breakdown = {
            "years": years,
            "months": months,
            "weeks": weeks,
            "days": days
        }
        
        # Build result string, omitting zero values
        parts = []
        if years > 0:
            parts.append(f"{years} Jahr{'e' if years > 1 else ''}")
        if months > 0:
            parts.append(f"{months} Monat{'e' if months > 1 else ''}")
        if weeks > 0:
            parts.append(f"{weeks} Woche{'n' if weeks > 1 else ''}")
        if days > 0:
            parts.append(f"{days} Tag{'e' if days > 1 else ''}")
        
        # Join with commas only (no 'und')
        if len(parts) == 0:
            return "0 Tage"
        else:
            return ", ".join(parts)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return the state attributes."""
        # Nur der Countdown Text Sensor bekommt Attribute
        if self._sensor_type == "countdown_text":
            attributes = {
                "event_name": self._event_data[CONF_EVENT_NAME],
                "event_type": self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_MILESTONE),
                "date": self._target_date.isoformat(),
            }
            
            # Add countdown breakdown attributes
            attributes.update(self._get_countdown_attributes())
            
            return attributes
        
        # Alle anderen Milestone-Sensoren haben keine Attribute
        return {}