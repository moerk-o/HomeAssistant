"""Base sensor classes for WhenHub integration."""
from __future__ import annotations

from datetime import date
from typing import Any

from homeassistant.components.sensor import SensorEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.helpers.entity import DeviceInfo

from ..const import (
    DOMAIN,
    EVENT_TYPES,
    EVENT_TYPE_TRIP,
    CONF_EVENT_TYPE,
    CONF_EVENT_NAME,
    CONF_IMAGE_PATH,
    CONF_WEBSITE_URL,
    CONF_NOTES,
    DEFAULT_IMAGE,
)


class BaseSensor(SensorEntity):
    """Base class for WhenHub sensors."""

    def __init__(
        self, 
        config_entry: ConfigEntry, 
        event_data: dict, 
        sensor_type: str, 
        sensor_types: dict
    ) -> None:
        """Initialize the sensor."""
        self._config_entry = config_entry
        self._event_data = event_data
        self._sensor_type = sensor_type
        self._sensor_types = sensor_types
        self._attr_name = f"{event_data[CONF_EVENT_NAME]} {sensor_types[sensor_type]['name']}"
        self._attr_unique_id = f"{config_entry.entry_id}_{sensor_type}"
        self._attr_icon = sensor_types[sensor_type]["icon"]
        self._attr_native_unit_of_measurement = sensor_types[sensor_type]["unit"]

    @property
    def device_info(self) -> DeviceInfo:
        """Return device information about this entity."""
        event_type = self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_TRIP)
        event_info = EVENT_TYPES.get(event_type, EVENT_TYPES[EVENT_TYPE_TRIP])
        
        return DeviceInfo(
            identifiers={(DOMAIN, self._config_entry.entry_id)},
            name=self._event_data[CONF_EVENT_NAME],
            manufacturer="WhenHub",
            model=event_info["model"],
            sw_version="1.0.0",
        )

    def _parse_date(self, date_str: str | date) -> date:
        """Parse date string or return date object."""
        if isinstance(date_str, str):
            return date.fromisoformat(date_str)
        return date_str

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return empty base state attributes - each sensor decides what it needs."""
        return {}

    async def async_update(self) -> None:
        """Update the sensor value."""
        pass


class BaseCountdownSensor(BaseSensor):
    """Base class for sensors with countdown functionality."""

    def __init__(
        self, 
        config_entry: ConfigEntry, 
        event_data: dict, 
        sensor_type: str, 
        sensor_types: dict
    ) -> None:
        """Initialize the countdown sensor."""
        super().__init__(config_entry, event_data, sensor_type, sensor_types)
        self._countdown_breakdown = {"years": 0, "months": 0, "weeks": 0, "days": 0}

    def _format_countdown_with_attributes(self, target_date: date) -> str:
        """Format countdown and store breakdown for attributes."""
        today = date.today()
        
        if target_date <= today:
            # Reset breakdown for "0 Tage"
            self._countdown_breakdown = {"years": 0, "months": 0, "weeks": 0, "days": 0}
            return "0 Tage"
        
        delta = target_date - today
        total_days = delta.days
        
        # Simple approximation approach for reliability
        years = total_days // 365
        remaining_days = total_days - (years * 365)
        
        months = remaining_days // 30
        remaining_days = remaining_days - (months * 30)
        
        weeks = remaining_days // 7
        days = remaining_days % 7
        
        # Store breakdown for attributes
        self._countdown_breakdown = {
            "years": years,
            "months": months,
            "weeks": weeks,
            "days": days
        }
        
        # Build result string, omitting zero values
        parts = []
        if years > 0:
            parts.append(f"{years} Jahr{'e' if years > 1 else ''}")
        if months > 0:
            parts.append(f"{months} Monat{'e' if months > 1 else ''}")
        if weeks > 0:
            parts.append(f"{weeks} Woche{'n' if weeks > 1 else ''}")
        if days > 0:
            parts.append(f"{days} Tag{'e' if days > 1 else ''}")
        
        # Join with commas only (no 'und')
        if len(parts) == 0:
            return "0 Tage"
        else:
            return ", ".join(parts)

    def _get_countdown_attributes(self) -> dict[str, int]:
        """Get standard countdown attributes."""
        return {
            "text_years": self._countdown_breakdown["years"],
            "text_months": self._countdown_breakdown["months"],
            "text_weeks": self._countdown_breakdown["weeks"],
            "text_days": self._countdown_breakdown["days"],
        }