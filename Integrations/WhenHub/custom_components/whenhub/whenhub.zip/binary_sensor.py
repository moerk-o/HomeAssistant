"""Binary sensor platform for WhenHub integration."""
from __future__ import annotations

import logging
from datetime import date
from typing import Any

from homeassistant.components.binary_sensor import BinarySensorEntity, BinarySensorDeviceClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import (
    DOMAIN,
    EVENT_TYPES,
    EVENT_TYPE_TRIP,
    EVENT_TYPE_MILESTONE,
    EVENT_TYPE_ANNIVERSARY,
    CONF_EVENT_TYPE,
    CONF_EVENT_NAME,
    CONF_START_DATE,
    CONF_END_DATE,
    CONF_TARGET_DATE,
    CONF_IMAGE_PATH,
    CONF_WEBSITE_URL,
    CONF_NOTES,
    TRIP_BINARY_SENSOR_TYPES,
    MILESTONE_BINARY_SENSOR_TYPES,
    ANNIVERSARY_BINARY_SENSOR_TYPES,
    DEFAULT_IMAGE,
)

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up WhenHub binary sensors based on a config entry."""
    event_data = hass.data[DOMAIN][config_entry.entry_id]
    
    # Determine event type
    event_type = event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_TRIP)
    
    binary_sensors = []
    
    if event_type == EVENT_TYPE_TRIP:
        for sensor_type in TRIP_BINARY_SENSOR_TYPES:
            binary_sensors.append(TripBinarySensor(config_entry, event_data, sensor_type))
            _LOGGER.debug("Created TripBinarySensor: %s", sensor_type)
    
    elif event_type == EVENT_TYPE_MILESTONE:
        for sensor_type in MILESTONE_BINARY_SENSOR_TYPES:
            binary_sensors.append(MilestoneBinarySensor(config_entry, event_data, sensor_type))
            _LOGGER.debug("Created MilestoneBinarySensor: %s", sensor_type)
    
    elif event_type == EVENT_TYPE_ANNIVERSARY:
        for sensor_type in ANNIVERSARY_BINARY_SENSOR_TYPES:
            binary_sensors.append(AnniversaryBinarySensor(config_entry, event_data, sensor_type))
            _LOGGER.debug("Created AnniversaryBinarySensor: %s", sensor_type)
    
    if binary_sensors:
        _LOGGER.info("Successfully created %d binary sensors for %s", len(binary_sensors), event_data[CONF_EVENT_NAME])
        async_add_entities(binary_sensors)
    else:
        _LOGGER.debug("No binary sensors created for event type: %s", event_type)


class TripBinarySensor(BinarySensorEntity):
    """Representation of a Trip Binary Sensor."""

    def __init__(self, config_entry: ConfigEntry, event_data: dict, sensor_type: str) -> None:
        """Initialize the trip binary sensor."""
        self._config_entry = config_entry
        self._event_data = event_data
        self._sensor_type = sensor_type
        self._sensor_types = TRIP_BINARY_SENSOR_TYPES
        self._attr_name = f"{event_data[CONF_EVENT_NAME]} {TRIP_BINARY_SENSOR_TYPES[sensor_type]['name']}"
        self._attr_unique_id = f"{config_entry.entry_id}_binary_{sensor_type}"
        self._attr_icon = TRIP_BINARY_SENSOR_TYPES[sensor_type]["icon"]
        
        # Set device class if specified
        device_class = TRIP_BINARY_SENSOR_TYPES[sensor_type].get("device_class")
        if device_class:
            self._attr_device_class = getattr(BinarySensorDeviceClass, device_class.upper(), None)
        
        # Parse dates
        self._start_date = self._parse_date(event_data[CONF_START_DATE])
        self._end_date = self._parse_date(event_data[CONF_END_DATE])
        
        # Calculate initial value
        try:
            self._attr_is_on = self._calculate_initial_value()
        except Exception as err:
            _LOGGER.error("Error calculating initial value for %s: %s", sensor_type, err)
            self._attr_is_on = False

    def _parse_date(self, date_str: str | date) -> date:
        """Parse date string or return date object."""
        if isinstance(date_str, str):
            return date.fromisoformat(date_str)
        return date_str

    @property
    def device_info(self) -> DeviceInfo:
        """Return device information about this entity."""
        event_type = self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_TRIP)
        event_info = EVENT_TYPES.get(event_type, EVENT_TYPES[EVENT_TYPE_TRIP])
        
        return DeviceInfo(
            identifiers={(DOMAIN, self._config_entry.entry_id)},
            name=self._event_data[CONF_EVENT_NAME],
            manufacturer="WhenHub",
            model=event_info["model"],
            sw_version="1.0.0",
        )

    def _calculate_initial_value(self) -> bool:
        """Calculate the initial value for this binary sensor."""
        if self._sensor_type == "trip_starts_today":
            return self._is_trip_starts_today()
        elif self._sensor_type == "trip_active_today":
            return self._is_trip_active_today()
        elif self._sensor_type == "trip_ends_today":
            return self._is_trip_ends_today()
        return False

    def _is_trip_starts_today(self) -> bool:
        """Check if today is the trip start date."""
        today = date.today()
        return today == self._start_date

    def _is_trip_active_today(self) -> bool:
        """Check if today is during the trip (start to end, inclusive)."""
        today = date.today()
        return self._start_date <= today <= self._end_date

    def _is_trip_ends_today(self) -> bool:
        """Check if today is the trip end date."""
        today = date.today()
        return today == self._end_date

    @property
    def is_on(self) -> bool:
        """Return true if the binary sensor is on."""
        try:
            if hasattr(self, '_attr_is_on'):
                return self._attr_is_on
            return self._calculate_value()
        except Exception as err:
            _LOGGER.error("Error in is_on for binary sensor %s: %s", self._sensor_type, err)
            return False

    def _calculate_value(self) -> bool:
        """Calculate the current value."""
        if self._sensor_type == "trip_starts_today":
            return self._is_trip_starts_today()
        elif self._sensor_type == "trip_active_today":
            return self._is_trip_active_today()
        elif self._sensor_type == "trip_ends_today":
            return self._is_trip_ends_today()
        return False

    async def async_update(self) -> None:
        """Update the binary sensor value."""
        try:
            new_value = self._calculate_value()
            self._attr_is_on = new_value
        except Exception as err:
            _LOGGER.error("Error updating binary sensor %s: %s", self._sensor_type, err)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return the state attributes."""
        # Trip Binary Sensors haben keine Attribute
        return {}


class MilestoneBinarySensor(BinarySensorEntity):
    """Representation of a Milestone Binary Sensor."""

    def __init__(self, config_entry: ConfigEntry, event_data: dict, sensor_type: str) -> None:
        """Initialize the milestone binary sensor."""
        self._config_entry = config_entry
        self._event_data = event_data
        self._sensor_type = sensor_type
        self._sensor_types = MILESTONE_BINARY_SENSOR_TYPES
        self._attr_name = f"{event_data[CONF_EVENT_NAME]} {MILESTONE_BINARY_SENSOR_TYPES[sensor_type]['name']}"
        self._attr_unique_id = f"{config_entry.entry_id}_binary_{sensor_type}"
        self._attr_icon = MILESTONE_BINARY_SENSOR_TYPES[sensor_type]["icon"]
        
        # Set device class if specified
        device_class = MILESTONE_BINARY_SENSOR_TYPES[sensor_type].get("device_class")
        if device_class:
            self._attr_device_class = getattr(BinarySensorDeviceClass, device_class.upper(), None)
        
        # Parse target date
        target_date = event_data.get(CONF_TARGET_DATE)
        if not target_date:
            _LOGGER.error("No target_date found for milestone binary sensor, event_data: %s", event_data)
            target_date = date.today().isoformat()
        
        self._target_date = self._parse_date(target_date)
        
        # Calculate initial value
        try:
            self._attr_is_on = self._calculate_initial_value()
        except Exception as err:
            _LOGGER.error("Error calculating initial value for %s: %s", sensor_type, err)
            self._attr_is_on = False

    def _parse_date(self, date_str: str | date) -> date:
        """Parse date string or return date object."""
        if isinstance(date_str, str):
            return date.fromisoformat(date_str)
        return date_str

    @property
    def device_info(self) -> DeviceInfo:
        """Return device information about this entity."""
        event_type = self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_MILESTONE)
        event_info = EVENT_TYPES.get(event_type, EVENT_TYPES[EVENT_TYPE_MILESTONE])
        
        return DeviceInfo(
            identifiers={(DOMAIN, self._config_entry.entry_id)},
            name=self._event_data[CONF_EVENT_NAME],
            manufacturer="WhenHub",
            model=event_info["model"],
            sw_version="1.0.0",
        )

    def _calculate_initial_value(self) -> bool:
        """Calculate the initial value for this binary sensor."""
        if self._sensor_type == "is_today":
            return self._is_milestone_today()
        return False

    def _is_milestone_today(self) -> bool:
        """Check if today is the milestone date."""
        today = date.today()
        return today == self._target_date

    @property
    def is_on(self) -> bool:
        """Return true if the binary sensor is on."""
        try:
            if hasattr(self, '_attr_is_on'):
                return self._attr_is_on
            return self._calculate_value()
        except Exception as err:
            _LOGGER.error("Error in is_on for binary sensor %s: %s", self._sensor_type, err)
            return False

    def _calculate_value(self) -> bool:
        """Calculate the current value."""
        if self._sensor_type == "is_today":
            return self._is_milestone_today()
        return False

    async def async_update(self) -> None:
        """Update the binary sensor value."""
        try:
            new_value = self._calculate_value()
            self._attr_is_on = new_value
        except Exception as err:
            _LOGGER.error("Error updating binary sensor %s: %s", self._sensor_type, err)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return the state attributes."""
        attributes = {
            "event_name": self._event_data[CONF_EVENT_NAME],
            "event_type": self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_MILESTONE),
            "target_date": self._target_date.isoformat(),
        }
        
        # Add optional attributes if provided
        if self._event_data.get(CONF_IMAGE_PATH):
            attributes["image_path"] = self._event_data[CONF_IMAGE_PATH]
        else:
            attributes["image_path"] = DEFAULT_IMAGE
            
        if self._event_data.get(CONF_WEBSITE_URL):
            attributes["website_url"] = self._event_data[CONF_WEBSITE_URL]
            
        if self._event_data.get(CONF_NOTES):
            attributes["notes"] = self._event_data[CONF_NOTES]
        
        return attributes


class AnniversaryBinarySensor(BinarySensorEntity):
    """Representation of an Anniversary Binary Sensor."""

    def __init__(self, config_entry: ConfigEntry, event_data: dict, sensor_type: str) -> None:
        """Initialize the anniversary binary sensor."""
        self._config_entry = config_entry
        self._event_data = event_data
        self._sensor_type = sensor_type
        self._sensor_types = ANNIVERSARY_BINARY_SENSOR_TYPES
        self._attr_name = f"{event_data[CONF_EVENT_NAME]} {ANNIVERSARY_BINARY_SENSOR_TYPES[sensor_type]['name']}"
        self._attr_unique_id = f"{config_entry.entry_id}_binary_{sensor_type}"
        self._attr_icon = ANNIVERSARY_BINARY_SENSOR_TYPES[sensor_type]["icon"]
        
        # Set device class if specified
        device_class = ANNIVERSARY_BINARY_SENSOR_TYPES[sensor_type].get("device_class")
        if device_class:
            self._attr_device_class = getattr(BinarySensorDeviceClass, device_class.upper(), None)
        
        # Parse original date
        target_date = event_data.get(CONF_TARGET_DATE)
        if not target_date:
            _LOGGER.error("No target_date found for anniversary binary sensor, event_data: %s", event_data)
            target_date = date.today().isoformat()
        
        self._original_date = self._parse_date(target_date)
        
        # Calculate initial value
        try:
            self._attr_is_on = self._calculate_initial_value()
        except Exception as err:
            _LOGGER.error("Error calculating initial value for %s: %s", sensor_type, err)
            self._attr_is_on = False

    def _parse_date(self, date_str: str | date) -> date:
        """Parse date string or return date object."""
        if isinstance(date_str, str):
            return date.fromisoformat(date_str)
        return date_str

    @property
    def device_info(self) -> DeviceInfo:
        """Return device information about this entity."""
        event_type = self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_ANNIVERSARY)
        event_info = EVENT_TYPES.get(event_type, EVENT_TYPES[EVENT_TYPE_ANNIVERSARY])
        
        return DeviceInfo(
            identifiers={(DOMAIN, self._config_entry.entry_id)},
            name=self._event_data[CONF_EVENT_NAME],
            manufacturer="WhenHub",
            model=event_info["model"],
            sw_version="1.0.0",
        )

    def _get_next_anniversary(self) -> date:
        """Calculate next anniversary date."""
        try:
            today = date.today()
            current_year = today.year
            
            # Try this year's anniversary
            try:
                this_year_anniversary = self._original_date.replace(year=current_year)
                if this_year_anniversary >= today:
                    return this_year_anniversary
            except ValueError:
                # Handle leap year edge case (Feb 29 -> Feb 28 in non-leap years)
                this_year_anniversary = date(current_year, 2, 28)
                if this_year_anniversary >= today:
                    return this_year_anniversary
            
            # If this year's anniversary has already passed, get next year's
            try:
                next_year_anniversary = self._original_date.replace(year=current_year + 1)
                return next_year_anniversary
            except ValueError:
                # Handle leap year edge case (Feb 29 -> Feb 28 in non-leap years)
                return date(current_year + 1, 2, 28)
                
        except Exception as err:
            _LOGGER.error("Error calculating next anniversary: %s", err)
            return self._original_date

    def _calculate_initial_value(self) -> bool:
        """Calculate the initial value for this binary sensor."""
        if self._sensor_type == "is_today":
            return self._is_anniversary_today()
        return False

    def _is_anniversary_today(self) -> bool:
        """Check if today is the anniversary."""
        today = date.today()
        next_anniversary = self._get_next_anniversary()
        return today == next_anniversary

    @property
    def is_on(self) -> bool:
        """Return true if the binary sensor is on."""
        try:
            if hasattr(self, '_attr_is_on'):
                return self._attr_is_on
            return self._calculate_value()
        except Exception as err:
            _LOGGER.error("Error in is_on for binary sensor %s: %s", self._sensor_type, err)
            return False

    def _calculate_value(self) -> bool:
        """Calculate the current value."""
        if self._sensor_type == "is_today":
            return self._is_anniversary_today()
        return False

    async def async_update(self) -> None:
        """Update the binary sensor value."""
        try:
            new_value = self._calculate_value()
            self._attr_is_on = new_value
        except Exception as err:
            _LOGGER.error("Error updating binary sensor %s: %s", self._sensor_type, err)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return the state attributes."""
        attributes = {
            "event_name": self._event_data[CONF_EVENT_NAME],
            "event_type": self._event_data.get(CONF_EVENT_TYPE, EVENT_TYPE_ANNIVERSARY),
            "original_date": self._original_date.isoformat(),
        }
        
        # Add optional attributes if provided
        if self._event_data.get(CONF_IMAGE_PATH):
            attributes["image_path"] = self._event_data[CONF_IMAGE_PATH]
        else:
            attributes["image_path"] = DEFAULT_IMAGE
            
        if self._event_data.get(CONF_WEBSITE_URL):
            attributes["website_url"] = self._event_data[CONF_WEBSITE_URL]
            
        if self._event_data.get(CONF_NOTES):
            attributes["notes"] = self._event_data[CONF_NOTES]
        
        # Add next anniversary info
        next_anniversary = self._get_next_anniversary()
        attributes.update({
            "next_anniversary": next_anniversary.isoformat(),
            "years_on_next": next_anniversary.year - self._original_date.year,
        })
        
        return attributes